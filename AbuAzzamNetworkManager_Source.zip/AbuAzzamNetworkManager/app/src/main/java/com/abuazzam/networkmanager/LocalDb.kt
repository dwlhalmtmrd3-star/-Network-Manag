package com.abuazzam.networkmanager

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class LocalDb(context: Context) : SQLiteOpenHelper(context, "abu_azzam_network.db", null, 1) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL(
            "CREATE TABLE vouchers (id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT NOT NULL UNIQUE, password TEXT NOT NULL, plan TEXT NOT NULL DEFAULT '', created_at INTEGER NOT NULL)"
        )
    }
    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    fun addVoucher(username: String, password: String, plan: String) {
        val values = ContentValues().apply {
            put("username", username)
            put("password", password)
            put("plan", plan)
            put("created_at", System.currentTimeMillis())
        }
        writableDatabase.insertWithOnConflict("vouchers", null, values, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun counts(): Pair<Int, Int> {
        readableDatabase.rawQuery("SELECT COUNT(*) FROM vouchers", null).use { c ->
            c.moveToFirst()
            val count = c.getInt(0)
            return Pair(count, count)
        }
    }

    fun vouchers(): List<Array<String>> {
        val result = mutableListOf<Array<String>>()
        readableDatabase.rawQuery("SELECT username, plan FROM vouchers ORDER BY id DESC", null).use { c ->
            while (c.moveToNext()) result.add(arrayOf(c.getString(0), c.getString(1)))
        }
        return result
    }
}

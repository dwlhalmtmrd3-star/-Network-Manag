package com.abuazzam.networkmanager

import android.app.Activity
import android.app.AlertDialog
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var db: LocalDb
    private lateinit var content: LinearLayout
    private val navy = Color.rgb(13, 27, 48)
    private val pale = Color.rgb(238, 242, 247)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        db = LocalDb(this)
        showDashboard()
    }

    private fun base(title: String) {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setBackgroundColor(pale)
            setPadding(18, 22, 18, 18)
        }
        val header = TextView(this).apply {
            text = "مدير الشبكة\n$title"
            textSize = 23f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            setPadding(12, 22, 12, 22)
            setBackgroundColor(navy)
        }
        outer.addView(header, LinearLayout.LayoutParams(-1, -2))
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            layoutDirection = View.LAYOUT_DIRECTION_RTL
            setPadding(0, 18, 0, 0)
        }
        val scroll = ScrollView(this)
        scroll.addView(content)
        outer.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val footer = TextView(this).apply {
            text = "أبو عزام • الإصدار التجريبي 0.1"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(navy)
            setPadding(8, 14, 8, 8)
        }
        outer.addView(footer)
        setContentView(outer)
    }

    private fun label(text: String, size: Float = 17f) =
        TextView(this).apply {
            this.text = text
            textSize = size
            setTextColor(navy)
            setPadding(4, 10, 4, 10)
        }

    private fun action(text: String, onClick: () -> Unit) {
        val b = Button(this).apply {
            this.text = text
            isAllCaps = false
            setTextColor(Color.WHITE)
            setBackgroundColor(navy)
            setOnClickListener { onClick() }
        }
        content.addView(b, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 8 })
    }

    private fun showDashboard() {
        base("أبو عزام")
        val stats = db.counts()
        content.addView(label("لوحة التحكم", 21f))
        content.addView(label("إجمالي الكروت: ${stats.first}"))
        content.addView(label("الكروت المحفوظة محلياً: ${stats.second}"))
        content.addView(label("نسخة أولية: تخزين محلي تجريبي."))
        action("إضافة كرت اشتراك") { addVoucherDialog() }
        action("عرض كروت الاشتراك") { showVouchers() }
        action("إعدادات ربط MikroTik") {
            AlertDialog.Builder(this)
                .setTitle("ربط MikroTik")
                .setMessage("الربط الفعلي يحتاج خادماً وسيطاً آمناً وVPN. لا تدخل كلمة مرور الراوتر في هذه النسخة.")
                .setPositiveButton("حسناً", null).show()
        }
        action("الاشتراك الشهري") {
            AlertDialog.Builder(this)
                .setTitle("اشتراك البرنامج")
                .setMessage("السعر المعتمد: 10 دولارات شهرياً. الدفع عبر تحويل بنكي للكريمي، والتفعيل بعد التحقق اليدوي. شاشة الدفع الفعلية غير مفعلة بعد.")
                .setPositiveButton("حسناً", null).show()
        }
    }

    private fun addVoucherDialog() {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 0)
        }
        val username = EditText(this).apply { hint = "اسم المستخدم" }
        val password = EditText(this).apply { hint = "كلمة المرور" }
        val plan = EditText(this).apply { hint = "اسم الباقة (مثلاً: شهرية)" }
        box.addView(username); box.addView(password); box.addView(plan)
        AlertDialog.Builder(this).setTitle("إضافة كرت محلي")
            .setView(box)
            .setNegativeButton("إلغاء", null)
            .setPositiveButton("حفظ") { _, _ ->
                val u = username.text.toString().trim()
                val p = password.text.toString().trim()
                val pl = plan.text.toString().trim()
                if (u.isNotEmpty() && p.isNotEmpty()) {
                    db.addVoucher(u, p, pl)
                    showVouchers()
                } else {
                    Toast.makeText(this, "أدخل اسم المستخدم وكلمة المرور", Toast.LENGTH_LONG).show()
                }
            }.show()
    }

    private fun showVouchers() {
        base("كروت الاشتراك")
        action("إضافة كرت جديد") { addVoucherDialog() }
        val rows = db.vouchers()
        if (rows.isEmpty()) content.addView(label("لا توجد كروت محفوظة بعد."))
        rows.forEach { row ->
            val card = TextView(this).apply {
                text = "المستخدم: ${row[0]}\nالباقة: ${row[1]}\nالحالة: محفوظ محلياً"
                textSize = 16f
                setTextColor(navy)
                setPadding(14, 14, 14, 14)
                setBackgroundColor(Color.WHITE)
            }
            content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 10 })
        }
        action("العودة للرئيسية") { showDashboard() }
    }

    override fun onDestroy() {
        super.onDestroy()
        db.close()
    }
}

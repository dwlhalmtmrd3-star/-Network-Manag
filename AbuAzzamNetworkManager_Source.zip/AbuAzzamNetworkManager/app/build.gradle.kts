plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.abuazzam.networkmanager"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.abuazzam.networkmanager"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "0.1-prototype"
    }
}
